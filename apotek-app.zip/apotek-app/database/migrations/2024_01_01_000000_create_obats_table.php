<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('obats', function (Blueprint $table) {
            $table->id();
            $table->string('nama')->index(); // Tambah index untuk search
            $table->string('kategori')->nullable()->index();
            $table->text('deskripsi')->nullable();
            $table->decimal('harga', 10, 2);
            $table->integer('stok')->default(0);
            $table->date('tanggal_kadaluarsa')->nullable();
            $table->string('produsen')->nullable();
            $table->enum('jenis_obat', ['Tablet', 'Kapsul', 'Sirup', 'Salep', 'Injeksi', 'Lainnya'])->default('Tablet');
            $table->boolean('resep_dokter')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('obats');
    }
};