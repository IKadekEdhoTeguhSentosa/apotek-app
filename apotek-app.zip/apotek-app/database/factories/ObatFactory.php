<?php

namespace Database\Factories;

use App\Models\Obat;
use Illuminate\Database\Eloquent\Factories\Factory;

class ObatFactory extends Factory
{
    protected $model = Obat::class;

    public function definition(): array
    {
        $kategoriList = ['Antibiotik', 'Analgesik', 'Antihistamin', 'Antidiabetes', 'Vitamin', 'Suplemen', 'Obat Batuk', 'Obat Lambung', 'Obat Luka'];
        $jenisObat = ['Tablet', 'Kapsul', 'Sirup', 'Salep', 'Injeksi', 'Lainnya'];
        $produsenList = ['PT. Kimia Farma', 'PT. Kalbe Farma', 'PT. Dexa Medica', 'PT. Sido Muncul', 'PT. Combiphar', 'PT. Tempo Scan Pacific', 'Sanofi', 'PT. Indofarma'];

        return [
            'nama' => $this->faker->randomElement([
                'Paracetamol', 'Amoxicillin', 'Vitamin C', 'OBH Combi', 
                'Bioplacenton', 'Omeprazole', 'CTM', 'Promag',
                'Bodrex', 'Mixagrip', 'Sangobion', 'Neurobion',
                'Antangin', 'Tolak Angin', 'Paramex', 'Oskadon'
            ]) . ' ' . $this->faker->numberBetween(50, 1000) . 'mg',
            'kategori' => $this->faker->randomElement($kategoriList),
            'deskripsi' => $this->faker->sentence(10),
            'harga' => $this->faker->numberBetween(5000, 500000),
            'stok' => $this->faker->numberBetween(0, 200),
            'tanggal_kadaluarsa' => $this->faker->dateTimeBetween('now', '+3 years'),
            'produsen' => $this->faker->randomElement($produsenList),
            'jenis_obat' => $this->faker->randomElement($jenisObat),
            'resep_dokter' => $this->faker->boolean(30), // 30% chance true
        ];
    }
}