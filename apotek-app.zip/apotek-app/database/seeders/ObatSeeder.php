<?php

namespace Database\Seeders;

use App\Models\Obat;
use Illuminate\Database\Seeder;

class ObatSeeder extends Seeder
{
    public function run(): void
    {
        // Generate 10 data dummy menggunakan Factory
        Obat::factory()->count(10)->create();

        // Atau bisa tambah data manual juga
        Obat::create([
            'nama' => 'Paracetamol 500mg',
            'kategori' => 'Analgesik',
            'deskripsi' => 'Obat untuk meredakan nyeri dan demam',
            'harga' => 5000,
            'stok' => 100,
            'tanggal_kadaluarsa' => now()->addYears(2),
            'produsen' => 'PT. Kimia Farma',
            'jenis_obat' => 'Tablet',
            'resep_dokter' => false,
        ]);
    }
}