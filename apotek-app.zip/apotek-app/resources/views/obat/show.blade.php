@extends('layouts.app')

@section('title', 'Detail Obat')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Detail Obat</h1>
    <div>
        <a href="{{ route('obat.edit', $obat) }}" class="btn btn-warning">
            <i class="bi bi-pencil"></i> Edit
        </a>
        <a href="{{ route('obat.index') }}" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Informasi Obat</h5>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <th width="200">Nama Obat</th>
                        <td>
                            <strong class="fs-5">{{ $obat->nama }}</strong>
                            @if($obat->resep_dokter)
                                <span class="badge bg-warning text-dark ms-2">Resep Dokter</span>
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <th>Kategori</th>
                        <td>{{ $obat->kategori ?? '-' }}</td>
                    </tr>
                    <tr>
                        <th>Jenis Obat</th>
                        <td><span class="badge bg-info">{{ $obat->jenis_obat }}</span></td>
                    </tr>
                    <tr>
                        <th>Deskripsi</th>
                        <td>{{ $obat->deskripsi ?? 'Tidak ada deskripsi' }}</td>
                    </tr>
                    <tr>
                        <th>Produsen</th>
                        <td>{{ $obat->produsen ?? '-' }}</td>
                    </tr>
                </table>
            </div>
        </div>

        @if($obat->deskripsi)
        <div class="card mt-3">
            <div class="card-header">
                <h6 class="mb-0">Deskripsi Lengkap</h6>
            </div>
            <div class="card-body">
                <p class="mb-0">{{ $obat->deskripsi }}</p>
            </div>
        </div>
        @endif
    </div>

    <div class="col-md-4">
        <!-- Card Harga & Stok -->
        <div class="card mb-3">
            <div class="card-header bg-success text-white">
                <h6 class="mb-0">Harga & Stok</h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <small class="text-muted">Harga</small>
                    <h3 class="text-success mb-0">{{ $obat->harga_format }}</h3>
                </div>
                <div class="mb-3">
                    <small class="text-muted">Stok Tersedia</small>
                    <h4>
                        @if($obat->stok <= 0)
                            <span class="badge bg-danger">Habis</span>
                        @elseif($obat->stok < 10)
                            <span class="badge bg-warning text-dark">{{ $obat->stok }} Unit</span>
                        @else
                            <span class="badge bg-success">{{ $obat->stok }} Unit</span>
                        @endif
                    </h4>
                </div>
                <div>
                    <small class="text-muted">Status Ketersediaan</small>
                    <p class="mb-0">
                        @if($obat->isStokTersedia())
                            <span class="badge bg-success">✓ Tersedia</span>
                        @else
                            <span class="badge bg-danger">✗ Tidak Tersedia</span>
                        @endif
                    </p>
                </div>
            </div>
        </div>

        <!-- Card Kadaluarsa -->
        <div class="card mb-3">
            <div class="card-header {{ $obat->isKadaluarsa() ? 'bg-danger' : 'bg-info' }} text-white">
                <h6 class="mb-0">Tanggal Kadaluarsa</h6>
            </div>
            <div class="card-body">
                @if($obat->tanggal_kadaluarsa)
                    <p class="mb-2">
                        <strong>{{ $obat->tanggal_kadaluarsa->format('d F Y') }}</strong>
                    </p>
                    @if($obat->isKadaluarsa())
                        <div class="alert alert-danger mb-0">
                            <small><strong>⚠️ Obat sudah kadaluarsa!</strong></small>
                        </div>
                    @else
                        <small class="text-muted">
                            Kadaluarsa dalam {{ $obat->tanggal_kadaluarsa->diffForHumans() }}
                        </small>
                    @endif
                @else
                    <p class="text-muted mb-0">Tidak ada informasi tanggal kadaluarsa</p>
                @endif
            </div>
        </div>

        <!-- Card Informasi Tambahan -->
        <div class="card">
            <div class="card-header bg-secondary text-white">
                <h6 class="mb-0">Informasi Tambahan</h6>
            </div>
            <div class="card-body">
                <small class="text-muted d-block mb-1">Ditambahkan</small>
                <p class="mb-2">{{ $obat->created_at->format('d F Y, H:i') }}</p>
                
                <small class="text-muted d-block mb-1">Terakhir Diupdate</small>
                <p class="mb-0">{{ $obat->updated_at->format('d F Y, H:i') }}</p>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="d-grid gap-2 mt-3">
            <a href="{{ route('obat.edit', $obat) }}" class="btn btn-warning">
                <i class="bi bi-pencil"></i> Edit Obat
            </a>
            <form action="{{ route('obat.destroy', $obat) }}" method="POST" class="d-inline">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger w-100" 
                        onclick="return confirm('Yakin ingin menghapus obat {{ $obat->nama }}?')">
                    <i class="bi bi-trash"></i> Hapus Obat
                </button>
            </form>
        </div>
    </div>
</div>
@endsection