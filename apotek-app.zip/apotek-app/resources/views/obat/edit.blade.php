@extends('layouts.app')

@section('title', 'Edit Obat')

@section('content')
<h1 class="mb-4">Edit Obat: {{ $obat->nama }}</h1>

<div class="card">
    <div class="card-body">
        <form action="{{ route('obat.update', $obat) }}" method="POST">
            @csrf
            @method('PUT')
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Obat <span class="text-danger">*</span></label>
                        <input type="text" class="form-control @error('nama') is-invalid @enderror" 
                               id="nama" name="nama" value="{{ old('nama', $obat->nama) }}" required>
                        @error('nama')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="kategori" class="form-label">Kategori</label>
                        <input type="text" class="form-control @error('kategori') is-invalid @enderror" 
                               id="kategori" name="kategori" value="{{ old('kategori', $obat->kategori) }}">
                        @error('kategori')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi</label>
                <textarea class="form-control @error('deskripsi') is-invalid @enderror" 
                          id="deskripsi" name="deskripsi" rows="3">{{ old('deskripsi', $obat->deskripsi) }}</textarea>
                @error('deskripsi')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="harga" class="form-label">Harga (Rp) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control @error('harga') is-invalid @enderror" 
                               id="harga" name="harga" value="{{ old('harga', $obat->harga) }}" 
                               required min="0" step="0.01">
                        @error('harga')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="stok" class="form-label">Stok <span class="text-danger">*</span></label>
                        <input type="number" class="form-control @error('stok') is-invalid @enderror" 
                               id="stok" name="stok" value="{{ old('stok', $obat->stok) }}" 
                               required min="0">
                        @error('stok')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="jenis_obat" class="form-label">Jenis Obat <span class="text-danger">*</span></label>
                        <select class="form-select @error('jenis_obat') is-invalid @enderror" 
                                id="jenis_obat" name="jenis_obat" required>
                            <option value="">Pilih Jenis</option>
                            <option value="Tablet" {{ old('jenis_obat', $obat->jenis_obat) == 'Tablet' ? 'selected' : '' }}>Tablet</option>
                            <option value="Kapsul" {{ old('jenis_obat', $obat->jenis_obat) == 'Kapsul' ? 'selected' : '' }}>Kapsul</option>
                            <option value="Sirup" {{ old('jenis_obat', $obat->jenis_obat) == 'Sirup' ? 'selected' : '' }}>Sirup</option>
                            <option value="Salep" {{ old('jenis_obat', $obat->jenis_obat) == 'Salep' ? 'selected' : '' }}>Salep</option>
                            <option value="Injeksi" {{ old('jenis_obat', $obat->jenis_obat) == 'Injeksi' ? 'selected' : '' }}>Injeksi</option>
                            <option value="Lainnya" {{ old('jenis_obat', $obat->jenis_obat) == 'Lainnya' ? 'selected' : '' }}>Lainnya</option>
                        </select>
                        @error('jenis_obat')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="tanggal_kadaluarsa" class="form-label">Tanggal Kadaluarsa</label>
                        <input type="date" class="form-control @error('tanggal_kadaluarsa') is-invalid @enderror" 
                               id="tanggal_kadaluarsa" name="tanggal_kadaluarsa" 
                               value="{{ old('tanggal_kadaluarsa', $obat->tanggal_kadaluarsa?->format('Y-m-d')) }}"
                               min="{{ date('Y-m-d') }}">
                        @error('tanggal_kadaluarsa')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="produsen" class="form-label">Produsen</label>
                        <input type="text" class="form-control @error('produsen') is-invalid @enderror" 
                               id="produsen" name="produsen" value="{{ old('produsen', $obat->produsen) }}">
                        @error('produsen')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="resep_dokter" 
                           name="resep_dokter" value="1" 
                           {{ old('resep_dokter', $obat->resep_dokter) ? 'checked' : '' }}>
                    <label class="form-check-label" for="resep_dokter">
                        Memerlukan Resep Dokter
                    </label>
                </div>
            </div>

            <hr>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save"></i> Update
                </button>
                <a href="{{ route('obat.index') }}" class="btn btn-secondary">
                    <i class="bi bi-x-circle"></i> Batal
                </a>
            </div>
        </form>
    </div>
</div>
@endsection