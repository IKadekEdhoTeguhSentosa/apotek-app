@extends('layouts.app')

@section('title', 'Daftar Obat')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Daftar Obat</h1>
    <a href="{{ route('obat.create') }}" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Tambah Obat
    </a>
</div>

@if(session('success'))
    <div class="alert alert-success alert-dismissible fade show">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
@endif

<!-- Search and Filter Form -->
<div class="card mb-4">
    <div class="card-body">
        <form action="{{ route('obat.index') }}" method="GET">
            <div class="row g-3">
                <div class="col-md-4">
                    <label for="search" class="form-label">Cari Obat</label>
                    <input type="text" class="form-control" id="search" name="search" 
                           value="{{ request('search') }}" 
                           placeholder="Nama, kategori, produsen...">
                </div>
                
                <div class="col-md-3">
                    <label for="kategori" class="form-label">Kategori</label>
                    <select class="form-select" id="kategori" name="kategori">
                        <option value="">Semua Kategori</option>
                        @foreach($categories as $cat)
                            <option value="{{ $cat }}" {{ request('kategori') == $cat ? 'selected' : '' }}>
                                {{ $cat }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="jenis_obat" class="form-label">Jenis Obat</label>
                    <select class="form-select" id="jenis_obat" name="jenis_obat">
                        <option value="">Semua Jenis</option>
                        @foreach($jenisObats as $jenis)
                            <option value="{{ $jenis }}" {{ request('jenis_obat') == $jenis ? 'selected' : '' }}>
                                {{ $jenis }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search"></i> Cari
                    </button>
                </div>
            </div>

            <div class="row mt-2">
                <div class="col-md-12">
                    <a href="{{ route('obat.index') }}" class="btn btn-secondary btn-sm">
                        <i class="bi bi-x-circle"></i> Reset Filter
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Results Info -->
<div class="mb-3">
    <p class="text-muted">
        Menampilkan {{ $obats->firstItem() ?? 0 }} - {{ $obats->lastItem() ?? 0 }} 
        dari {{ $obats->total() }} obat
        @if(request('search'))
            untuk pencarian: <strong>"{{ request('search') }}"</strong>
        @endif
    </p>
</div>

<!-- Table -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>
                            <a href="{{ route('obat.index', array_merge(request()->all(), ['sort_by' => 'nama', 'sort_order' => request('sort_order') == 'asc' ? 'desc' : 'asc'])) }}" 
                               class="text-white text-decoration-none">
                                Nama Obat
                                @if(request('sort_by') == 'nama')
                                    <i class="bi bi-arrow-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                @endif
                            </a>
                        </th>
                        <th>Kategori</th>
                        <th>Jenis</th>
                        <th>
                            <a href="{{ route('obat.index', array_merge(request()->all(), ['sort_by' => 'harga', 'sort_order' => request('sort_order') == 'asc' ? 'desc' : 'asc'])) }}" 
                               class="text-white text-decoration-none">
                                Harga
                                @if(request('sort_by') == 'harga')
                                    <i class="bi bi-arrow-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                @endif
                            </a>
                        </th>
                        <th>
                            <a href="{{ route('obat.index', array_merge(request()->all(), ['sort_by' => 'stok', 'sort_order' => request('sort_order') == 'asc' ? 'desc' : 'asc'])) }}" 
                               class="text-white text-decoration-none">
                                Stok
                                @if(request('sort_by') == 'stok')
                                    <i class="bi bi-arrow-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                @endif
                            </a>
                        </th>
                        <th>Status</th>
                        <th width="180">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($obats as $index => $obat)
                    <tr>
                        <td>{{ $obats->firstItem() + $index }}</td>
                        <td>
                            <strong>{{ $obat->nama }}</strong>
                            @if($obat->resep_dokter)
                                <span class="badge bg-warning text-dark">Resep Dokter</span>
                            @endif
                        </td>
                        <td>{{ $obat->kategori ?? '-' }}</td>
                        <td><span class="badge bg-info">{{ $obat->jenis_obat }}</span></td>
                        <td>{{ $obat->harga_format }}</td>
                        <td>
                            @if($obat->stok <= 0)
                                <span class="badge bg-danger">Habis</span>
                            @elseif($obat->stok < 10)
                                <span class="badge bg-warning text-dark">{{ $obat->stok }}</span>
                            @else
                                <span class="badge bg-success">{{ $obat->stok }}</span>
                            @endif
                        </td>
                        <td>
                            @if($obat->isKadaluarsa())
                                <span class="badge bg-danger">Kadaluarsa</span>
                            @else
                                <span class="badge bg-success">Aktif</span>
                            @endif
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="{{ route('obat.show', $obat) }}" 
                                   class="btn btn-info btn-sm" 
                                   title="Detail"
                                   data-bs-toggle="tooltip">
                                    <i class="bi bi-eye"></i> Detail
                                </a>
                                <a href="{{ route('obat.edit', $obat) }}" 
                                   class="btn btn-warning btn-sm" 
                                   title="Edit"
                                   data-bs-toggle="tooltip">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                                <form action="{{ route('obat.destroy', $obat) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" 
                                            class="btn btn-danger btn-sm" 
                                            onclick="return confirm('Yakin ingin menghapus obat {{ $obat->nama }}?')"
                                            title="Hapus"
                                            data-bs-toggle="tooltip">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            <p class="text-muted mb-0">
                                @if(request('search'))
                                    Tidak ada hasil untuk pencarian "{{ request('search') }}"
                                @else
                                    Belum ada data obat
                                @endif
                            </p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        
        <!-- Custom Pagination with Bootstrap 5 -->
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div>
                <p class="text-muted mb-0">
                    Halaman {{ $obats->currentPage() }} dari {{ $obats->lastPage() }}
                </p>
            </div>
            <nav aria-label="Page navigation">
                <ul class="pagination mb-0">
                    {{-- Previous Button --}}
                    @if ($obats->onFirstPage())
                        <li class="page-item disabled">
                            <span class="page-link">
                                <i class="bi bi-chevron-left"></i> Sebelumnya
                            </span>
                        </li>
                    @else
                        <li class="page-item">
                            <a class="page-link" href="{{ $obats->previousPageUrl() }}&{{ http_build_query(request()->except('page')) }}">
                                <i class="bi bi-chevron-left"></i> Sebelumnya
                            </a>
                        </li>
                    @endif

                    {{-- Page Numbers --}}
                    @foreach ($obats->getUrlRange(1, $obats->lastPage()) as $page => $url)
                        @if ($page == $obats->currentPage())
                            <li class="page-item active">
                                <span class="page-link">{{ $page }}</span>
                            </li>
                        @else
                            <li class="page-item">
                                <a class="page-link" href="{{ $url }}&{{ http_build_query(request()->except('page')) }}">{{ $page }}</a>
                            </li>
                        @endif
                    @endforeach

                    {{-- Next Button --}}
                    @if ($obats->hasMorePages())
                        <li class="page-item">
                            <a class="page-link" href="{{ $obats->nextPageUrl() }}&{{ http_build_query(request()->except('page')) }}">
                                Selanjutnya <i class="bi bi-chevron-right"></i>
                            </a>
                        </li>
                    @else
                        <li class="page-item disabled">
                            <span class="page-link">
                                Selanjutnya <i class="bi bi-chevron-right"></i>
                            </span>
                        </li>
                    @endif
                </ul>
            </nav>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mt-4">
    <div class="col-md-4">
        <div class="card text-white bg-danger">
            <div class="card-body">
                <h5 class="card-title">Stok Habis</h5>
                <p class="card-text display-6">{{ \App\Models\Obat::stokHabis()->count() }}</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <h5 class="card-title">Stok Menipis</h5>
                <p class="card-text display-6">{{ \App\Models\Obat::stokMenupis()->count() }}</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h5 class="card-title">Total Obat</h5>
                <p class="card-text display-6">{{ \App\Models\Obat::count() }}</p>
            </div>
        </div>
    </div>
</div>
@endsection