<footer class="bg-dark text-white text-center py-3 mt-5">
    <div class="container">
        <p class="mb-0">&copy; 2024 Apotek Sehat. All rights reserved.</p>
    </div>
</footer><?php /**PATH C:\apotek-app\resources\views/partials/footer.blade.php ENDPATH**/ ?>