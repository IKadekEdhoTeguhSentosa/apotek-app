

<?php $__env->startSection('title', 'Home - Apotek Sehat'); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center">
    <h1 class="display-4">Selamat Datang di Apotek Sehat</h1>
    <p class="lead">Solusi kesehatan Anda, obat berkualitas dengan harga terjangkau</p>
    <a href="<?php echo e(route('obat.index')); ?>" class="btn btn-primary btn-lg">Lihat Daftar Obat</a>
</div>

<div class="row mt-5">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center">
                <h3>💊</h3>
                <h5>Obat Lengkap</h5>
                <p>Berbagai jenis obat tersedia</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center">
                <h3>👨‍⚕️</h3>
                <h5>Apoteker Profesional</h5>
                <p>Konsultasi gratis dengan apoteker</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center">
                <h3>🚚</h3>
                <h5>Pengiriman Cepat</h5>
                <p>Layanan antar ke rumah</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\apotek-app\resources\views/home.blade.php ENDPATH**/ ?>