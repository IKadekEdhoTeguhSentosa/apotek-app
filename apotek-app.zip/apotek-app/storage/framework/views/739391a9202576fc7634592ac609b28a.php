

<?php $__env->startSection('title', 'Tentang - Apotek Sehat'); ?>

<?php $__env->startSection('content'); ?>
<h1>Tentang Apotek Sehat</h1>
<div class="card">
    <div class="card-body">
        <h5 class="card-title">Apotek Terpercaya Sejak 2020</h5>
        <p class="card-text">
            Apotek Sehat adalah apotek yang berkomitmen menyediakan obat-obatan berkualitas 
            dengan harga terjangkau. Kami melayani dengan sepenuh hati untuk kesehatan Anda.
        </p>
        <h6>Visi:</h6>
        <p>Menjadi apotek pilihan utama masyarakat dalam memenuhi kebutuhan kesehatan.</p>
        
        <h6>Misi:</h6>
        <ul>
            <li>Menyediakan obat berkualitas tinggi</li>
            <li>Memberikan pelayanan terbaik kepada pelanggan</li>
            <li>Edukasi kesehatan kepada masyarakat</li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\apotek-app\resources\views/tentang.blade.php ENDPATH**/ ?>