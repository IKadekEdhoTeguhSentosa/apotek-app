

<?php $__env->startSection('title', 'Detail Obat'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Detail Obat</h1>
    <div>
        <a href="<?php echo e(route('obat.edit', $obat)); ?>" class="btn btn-warning">
            <i class="bi bi-pencil"></i> Edit
        </a>
        <a href="<?php echo e(route('obat.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Informasi Obat</h5>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <th width="200">Nama Obat</th>
                        <td>
                            <strong class="fs-5"><?php echo e($obat->nama); ?></strong>
                            <?php if($obat->resep_dokter): ?>
                                <span class="badge bg-warning text-dark ms-2">Resep Dokter</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Kategori</th>
                        <td><?php echo e($obat->kategori ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Jenis Obat</th>
                        <td><span class="badge bg-info"><?php echo e($obat->jenis_obat); ?></span></td>
                    </tr>
                    <tr>
                        <th>Deskripsi</th>
                        <td><?php echo e($obat->deskripsi ?? 'Tidak ada deskripsi'); ?></td>
                    </tr>
                    <tr>
                        <th>Produsen</th>
                        <td><?php echo e($obat->produsen ?? '-'); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <?php if($obat->deskripsi): ?>
        <div class="card mt-3">
            <div class="card-header">
                <h6 class="mb-0">Deskripsi Lengkap</h6>
            </div>
            <div class="card-body">
                <p class="mb-0"><?php echo e($obat->deskripsi); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="col-md-4">
        <!-- Card Harga & Stok -->
        <div class="card mb-3">
            <div class="card-header bg-success text-white">
                <h6 class="mb-0">Harga & Stok</h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <small class="text-muted">Harga</small>
                    <h3 class="text-success mb-0"><?php echo e($obat->harga_format); ?></h3>
                </div>
                <div class="mb-3">
                    <small class="text-muted">Stok Tersedia</small>
                    <h4>
                        <?php if($obat->stok <= 0): ?>
                            <span class="badge bg-danger">Habis</span>
                        <?php elseif($obat->stok < 10): ?>
                            <span class="badge bg-warning text-dark"><?php echo e($obat->stok); ?> Unit</span>
                        <?php else: ?>
                            <span class="badge bg-success"><?php echo e($obat->stok); ?> Unit</span>
                        <?php endif; ?>
                    </h4>
                </div>
                <div>
                    <small class="text-muted">Status Ketersediaan</small>
                    <p class="mb-0">
                        <?php if($obat->isStokTersedia()): ?>
                            <span class="badge bg-success">✓ Tersedia</span>
                        <?php else: ?>
                            <span class="badge bg-danger">✗ Tidak Tersedia</span>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- Card Kadaluarsa -->
        <div class="card mb-3">
            <div class="card-header <?php echo e($obat->isKadaluarsa() ? 'bg-danger' : 'bg-info'); ?> text-white">
                <h6 class="mb-0">Tanggal Kadaluarsa</h6>
            </div>
            <div class="card-body">
                <?php if($obat->tanggal_kadaluarsa): ?>
                    <p class="mb-2">
                        <strong><?php echo e($obat->tanggal_kadaluarsa->format('d F Y')); ?></strong>
                    </p>
                    <?php if($obat->isKadaluarsa()): ?>
                        <div class="alert alert-danger mb-0">
                            <small><strong>⚠️ Obat sudah kadaluarsa!</strong></small>
                        </div>
                    <?php else: ?>
                        <small class="text-muted">
                            Kadaluarsa dalam <?php echo e($obat->tanggal_kadaluarsa->diffForHumans()); ?>

                        </small>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="text-muted mb-0">Tidak ada informasi tanggal kadaluarsa</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Card Informasi Tambahan -->
        <div class="card">
            <div class="card-header bg-secondary text-white">
                <h6 class="mb-0">Informasi Tambahan</h6>
            </div>
            <div class="card-body">
                <small class="text-muted d-block mb-1">Ditambahkan</small>
                <p class="mb-2"><?php echo e($obat->created_at->format('d F Y, H:i')); ?></p>
                
                <small class="text-muted d-block mb-1">Terakhir Diupdate</small>
                <p class="mb-0"><?php echo e($obat->updated_at->format('d F Y, H:i')); ?></p>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="d-grid gap-2 mt-3">
            <a href="<?php echo e(route('obat.edit', $obat)); ?>" class="btn btn-warning">
                <i class="bi bi-pencil"></i> Edit Obat
            </a>
            <form action="<?php echo e(route('obat.destroy', $obat)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger w-100" 
                        onclick="return confirm('Yakin ingin menghapus obat <?php echo e($obat->nama); ?>?')">
                    <i class="bi bi-trash"></i> Hapus Obat
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\apotek-app\resources\views/obat/show.blade.php ENDPATH**/ ?>