

<?php $__env->startSection('title', 'Daftar Obat'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Daftar Obat</h1>
    <a href="<?php echo e(route('obat.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Tambah Obat
    </a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Search and Filter Form -->
<div class="card mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('obat.index')); ?>" method="GET">
            <div class="row g-3">
                <div class="col-md-4">
                    <label for="search" class="form-label">Cari Obat</label>
                    <input type="text" class="form-control" id="search" name="search" 
                           value="<?php echo e(request('search')); ?>" 
                           placeholder="Nama, kategori, produsen...">
                </div>
                
                <div class="col-md-3">
                    <label for="kategori" class="form-label">Kategori</label>
                    <select class="form-select" id="kategori" name="kategori">
                        <option value="">Semua Kategori</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat); ?>" <?php echo e(request('kategori') == $cat ? 'selected' : ''); ?>>
                                <?php echo e($cat); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="jenis_obat" class="form-label">Jenis Obat</label>
                    <select class="form-select" id="jenis_obat" name="jenis_obat">
                        <option value="">Semua Jenis</option>
                        <?php $__currentLoopData = $jenisObats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jenis); ?>" <?php echo e(request('jenis_obat') == $jenis ? 'selected' : ''); ?>>
                                <?php echo e($jenis); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search"></i> Cari
                    </button>
                </div>
            </div>

            <div class="row mt-2">
                <div class="col-md-12">
                    <a href="<?php echo e(route('obat.index')); ?>" class="btn btn-secondary btn-sm">
                        <i class="bi bi-x-circle"></i> Reset Filter
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Results Info -->
<div class="mb-3">
    <p class="text-muted">
        Menampilkan <?php echo e($obats->firstItem() ?? 0); ?> - <?php echo e($obats->lastItem() ?? 0); ?> 
        dari <?php echo e($obats->total()); ?> obat
        <?php if(request('search')): ?>
            untuk pencarian: <strong>"<?php echo e(request('search')); ?>"</strong>
        <?php endif; ?>
    </p>
</div>

<!-- Table -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>
                            <a href="<?php echo e(route('obat.index', array_merge(request()->all(), ['sort_by' => 'nama', 'sort_order' => request('sort_order') == 'asc' ? 'desc' : 'asc']))); ?>" 
                               class="text-white text-decoration-none">
                                Nama Obat
                                <?php if(request('sort_by') == 'nama'): ?>
                                    <i class="bi bi-arrow-<?php echo e(request('sort_order') == 'asc' ? 'up' : 'down'); ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>Kategori</th>
                        <th>Jenis</th>
                        <th>
                            <a href="<?php echo e(route('obat.index', array_merge(request()->all(), ['sort_by' => 'harga', 'sort_order' => request('sort_order') == 'asc' ? 'desc' : 'asc']))); ?>" 
                               class="text-white text-decoration-none">
                                Harga
                                <?php if(request('sort_by') == 'harga'): ?>
                                    <i class="bi bi-arrow-<?php echo e(request('sort_order') == 'asc' ? 'up' : 'down'); ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="<?php echo e(route('obat.index', array_merge(request()->all(), ['sort_by' => 'stok', 'sort_order' => request('sort_order') == 'asc' ? 'desc' : 'asc']))); ?>" 
                               class="text-white text-decoration-none">
                                Stok
                                <?php if(request('sort_by') == 'stok'): ?>
                                    <i class="bi bi-arrow-<?php echo e(request('sort_order') == 'asc' ? 'up' : 'down'); ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>Status</th>
                        <th width="180">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $obats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($obats->firstItem() + $index); ?></td>
                        <td>
                            <strong><?php echo e($obat->nama); ?></strong>
                            <?php if($obat->resep_dokter): ?>
                                <span class="badge bg-warning text-dark">Resep Dokter</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($obat->kategori ?? '-'); ?></td>
                        <td><span class="badge bg-info"><?php echo e($obat->jenis_obat); ?></span></td>
                        <td><?php echo e($obat->harga_format); ?></td>
                        <td>
                            <?php if($obat->stok <= 0): ?>
                                <span class="badge bg-danger">Habis</span>
                            <?php elseif($obat->stok < 10): ?>
                                <span class="badge bg-warning text-dark"><?php echo e($obat->stok); ?></span>
                            <?php else: ?>
                                <span class="badge bg-success"><?php echo e($obat->stok); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($obat->isKadaluarsa()): ?>
                                <span class="badge bg-danger">Kadaluarsa</span>
                            <?php else: ?>
                                <span class="badge bg-success">Aktif</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('obat.show', $obat)); ?>" 
                                   class="btn btn-info btn-sm" 
                                   title="Detail"
                                   data-bs-toggle="tooltip">
                                    <i class="bi bi-eye"></i> Detail
                                </a>
                                <a href="<?php echo e(route('obat.edit', $obat)); ?>" 
                                   class="btn btn-warning btn-sm" 
                                   title="Edit"
                                   data-bs-toggle="tooltip">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                                <form action="<?php echo e(route('obat.destroy', $obat)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="btn btn-danger btn-sm" 
                                            onclick="return confirm('Yakin ingin menghapus obat <?php echo e($obat->nama); ?>?')"
                                            title="Hapus"
                                            data-bs-toggle="tooltip">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            <p class="text-muted mb-0">
                                <?php if(request('search')): ?>
                                    Tidak ada hasil untuk pencarian "<?php echo e(request('search')); ?>"
                                <?php else: ?>
                                    Belum ada data obat
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Custom Pagination with Bootstrap 5 -->
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div>
                <p class="text-muted mb-0">
                    Halaman <?php echo e($obats->currentPage()); ?> dari <?php echo e($obats->lastPage()); ?>

                </p>
            </div>
            <nav aria-label="Page navigation">
                <ul class="pagination mb-0">
                    
                    <?php if($obats->onFirstPage()): ?>
                        <li class="page-item disabled">
                            <span class="page-link">
                                <i class="bi bi-chevron-left"></i> Sebelumnya
                            </span>
                        </li>
                    <?php else: ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($obats->previousPageUrl()); ?>&<?php echo e(http_build_query(request()->except('page'))); ?>">
                                <i class="bi bi-chevron-left"></i> Sebelumnya
                            </a>
                        </li>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $obats->getUrlRange(1, $obats->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $obats->currentPage()): ?>
                            <li class="page-item active">
                                <span class="page-link"><?php echo e($page); ?></span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($url); ?>&<?php echo e(http_build_query(request()->except('page'))); ?>"><?php echo e($page); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($obats->hasMorePages()): ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($obats->nextPageUrl()); ?>&<?php echo e(http_build_query(request()->except('page'))); ?>">
                                Selanjutnya <i class="bi bi-chevron-right"></i>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link">
                                Selanjutnya <i class="bi bi-chevron-right"></i>
                            </span>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mt-4">
    <div class="col-md-4">
        <div class="card text-white bg-danger">
            <div class="card-body">
                <h5 class="card-title">Stok Habis</h5>
                <p class="card-text display-6"><?php echo e(\App\Models\Obat::stokHabis()->count()); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <h5 class="card-title">Stok Menipis</h5>
                <p class="card-text display-6"><?php echo e(\App\Models\Obat::stokMenupis()->count()); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h5 class="card-title">Total Obat</h5>
                <p class="card-text display-6"><?php echo e(\App\Models\Obat::count()); ?></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\apotek-app\resources\views/obat/index.blade.php ENDPATH**/ ?>