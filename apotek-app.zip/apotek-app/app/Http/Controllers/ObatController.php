<?php

namespace App\Http\Controllers;

use App\Models\Obat;
use Illuminate\Http\Request;

class ObatController extends Controller
{
    /**
     * Display a listing with search and pagination
     */
    public function index(Request $request)
    {
        $query = Obat::query();

        // Search functionality
        if ($request->has('search') && $request->search != '') {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('nama', 'LIKE', "%{$search}%")
                  ->orWhere('kategori', 'LIKE', "%{$search}%")
                  ->orWhere('produsen', 'LIKE', "%{$search}%")
                  ->orWhere('jenis_obat', 'LIKE', "%{$search}%");
            });
        }

        // Filter by kategori
        if ($request->has('kategori') && $request->kategori != '') {
            $query->where('kategori', $request->kategori);
        }

        // Filter by jenis_obat
        if ($request->has('jenis_obat') && $request->jenis_obat != '') {
            $query->where('jenis_obat', $request->jenis_obat);
        }

        // Sorting
        $sortBy = $request->get('sort_by', 'created_at');
        $sortOrder = $request->get('sort_order', 'desc');
        $query->orderBy($sortBy, $sortOrder);

        // Pagination with 10 items per page
        $obats = $query->paginate(10)->withQueryString();

        // Get unique categories and jenis for filter dropdown
        $categories = Obat::distinct()->pluck('kategori')->filter();
        $jenisObats = ['Tablet', 'Kapsul', 'Sirup', 'Salep', 'Injeksi', 'Lainnya'];

        return view('obat.index', compact('obats', 'categories', 'jenisObats'));
    }

    public function create()
    {
        return view('obat.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'kategori' => 'nullable|string|max:255',
            'deskripsi' => 'nullable|string',
            'harga' => 'required|numeric|min:0',
            'stok' => 'required|integer|min:0',
            'tanggal_kadaluarsa' => 'nullable|date|after:today',
            'produsen' => 'nullable|string|max:255',
            'jenis_obat' => 'required|in:Tablet,Kapsul,Sirup,Salep,Injeksi,Lainnya',
            'resep_dokter' => 'nullable|boolean',
        ]);

        Obat::create($validated);

        return redirect()->route('obat.index')
            ->with('success', 'Obat berhasil ditambahkan!');
    }

    public function show(Obat $obat)
    {
        return view('obat.show', compact('obat'));
    }

    public function edit(Obat $obat)
    {
        return view('obat.edit', compact('obat'));
    }

    public function update(Request $request, Obat $obat)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'kategori' => 'nullable|string|max:255',
            'deskripsi' => 'nullable|string',
            'harga' => 'required|numeric|min:0',
            'stok' => 'required|integer|min:0',
            'tanggal_kadaluarsa' => 'nullable|date|after:today',
            'produsen' => 'nullable|string|max:255',
            'jenis_obat' => 'required|in:Tablet,Kapsul,Sirup,Salep,Injeksi,Lainnya',
            'resep_dokter' => 'nullable|boolean',
        ]);

        $obat->update($validated);

        return redirect()->route('obat.index')
            ->with('success', 'Obat berhasil diupdate!');
    }

    public function destroy(Obat $obat)
    {
        $obat->delete();

        return redirect()->route('obat.index')
            ->with('success', 'Obat berhasil dihapus!');
    }
}