<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Obat extends Model
{
    use HasFactory;

    /**
     * Nama tabel di database
     */
    protected $table = 'obats';

    /**
     * Field yang boleh diisi mass assignment
     */
    protected $fillable = [
        'nama',
        'kategori',
        'deskripsi',
        'harga',
        'stok',
        'tanggal_kadaluarsa',
        'produsen',
        'jenis_obat',
        'resep_dokter',
    ];

    /**
     * Field yang di-cast ke tipe data tertentu
     */
    protected $casts = [
        'harga' => 'decimal:2',
        'stok' => 'integer',
        'tanggal_kadaluarsa' => 'date',
        'resep_dokter' => 'boolean',
    ];

    /**
     * Accessor untuk format harga Rupiah
     */
    public function getHargaFormatAttribute()
    {
        // Cast ke float untuk menghindari error type
        $harga = floatval($this->harga);
        return 'Rp ' . number_format($harga, 0, ',', '.');
    }

    /**
     * Scope untuk obat yang stoknya habis
     */
    public function scopeStokHabis($query)
    {
        return $query->where('stok', '<=', 0);
    }

    /**
     * Scope untuk obat yang stoknya menipis (kurang dari 10)
     */
    public function scopeStokMenupis($query)
    {
        return $query->where('stok', '>', 0)->where('stok', '<', 10);
    }

    /**
     * Scope untuk obat yang butuh resep dokter
     */
    public function scopeButuhResep($query)
    {
        return $query->where('resep_dokter', true);
    }

    /**
     * Cek apakah obat sudah kadaluarsa
     */
    public function isKadaluarsa()
    {
        // Cek jika tanggal_kadaluarsa null
        if (!$this->tanggal_kadaluarsa) {
            return false;
        }
        
        // Bandingkan dengan tanggal sekarang
        return $this->tanggal_kadaluarsa < Carbon::now();
    }

    /**
     * Cek apakah stok mencukupi
     */
    public function isStokTersedia($jumlah = 1)
    {
        return $this->stok >= $jumlah;
    }
}