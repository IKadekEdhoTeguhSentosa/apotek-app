<?php

use App\Http\Controllers\ObatController;
use Illuminate\Support\Facades\Route;

// Route halaman home
Route::get('/', function () {
    return view('home');
})->name('home');

// Route halaman tentang apotek
Route::get('/tentang', function () {
    return view('tentang');
})->name('tentang');

// Route CRUD untuk data obat
Route::resource('obat', ObatController::class);